from django import forms
from .models import User
from django.contrib.auth import authenticate


class Signup(forms.ModelForm):
    class Meta:
        model = User
        fields = ('email', 'password', 'username', 'tel', 'dob', 'address')

